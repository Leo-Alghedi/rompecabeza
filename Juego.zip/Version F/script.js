document.addEventListener('DOMContentLoaded', () => {
    const levels = [
        {
            pieces: [
                { id: 'piece1', order: 1, img: 'images/image1.jpg' },
                { id: 'piece2', order: 2, img: 'images/image2.jpg' },
                { id: 'piece3', order: 3, img: 'images/image3.jpg' },
                { id: 'piece4', order: 4, img: 'images/image4.jpg' },
                { id: 'piece5', order: 5, img: 'images/image5.jpg' },
                { id: 'piece6', order: 6, img: 'images/image6.jpg' },
                { id: 'piece7', order: 7, img: 'images/image7.jpg' },
                { id: 'piece8', order: 8, img: 'images/image8.jpg' },
                { id: 'piece9', order: 9, img: 'images/image9.jpg' },
            ],
            finalImage: 'images/final-image1.jpg'
        },
        {
            pieces: [
                { id: 'piece10', order: 1, img: 'images/image10.jpg' },
                { id: 'piece11', order: 2, img: 'images/image11.jpg' },
                { id: 'piece12', order: 3, img: 'images/image12.jpg' },
                { id: 'piece13', order: 4, img: 'images/image13.jpg' },
                { id: 'piece14', order: 5, img: 'images/image14.jpg' },
                { id: 'piece15', order: 6, img: 'images/image15.jpg' },
                { id: 'piece16', order: 7, img: 'images/image16.jpg' },
                { id: 'piece17', order: 8, img: 'images/image17.jpg' },
                { id: 'piece18', order: 9, img: 'images/image18.jpg' },
            ],
            finalImage: 'images/final-image2.jpg'
        },
        {
            pieces: [
                { id: 'piece19', order: 1, img: 'images/image19.jpg' },
                { id: 'piece20', order: 2, img: 'images/image20.jpg' },
                { id: 'piece21', order: 3, img: 'images/image21.jpg' },
                { id: 'piece22', order: 4, img: 'images/image22.jpg' },
                { id: 'piece23', order: 5, img: 'images/image23.jpg' },
                { id: 'piece24', order: 6, img: 'images/image24.jpg' },
                { id: 'piece25', order: 7, img: 'images/image25.jpg' },
                { id: 'piece26', order: 8, img: 'images/image26.jpg' },
                { id: 'piece27', order: 9, img: 'images/image27.jpg' },
            ],
            finalImage: 'images/final-image3.jpg'
        },
        {
            pieces: [
                { id: 'piece28', order: 1, img: 'images/image28.jpg' },
                { id: 'piece29', order: 2, img: 'images/image29.jpg' },
                { id: 'piece30', order: 3, img: 'images/image30.jpg' },
                { id: 'piece31', order: 4, img: 'images/image31.jpg' },
                { id: 'piece32', order: 5, img: 'images/image32.jpg' },
                { id: 'piece33', order: 6, img: 'images/image33.jpg' },
                { id: 'piece34', order: 7, img: 'images/image34.jpg' },
                { id: 'piece35', order: 8, img: 'images/image35.jpg' },
                { id: 'piece36', order: 9, img: 'images/image36.jpg' },
            ],
            finalImage: 'images/final-image4.jpg'
        },
        {
            pieces: [
                { id: 'piece37', order: 1, img: 'images/image37.jpg' },
                { id: 'piece38', order: 2, img: 'images/image38.jpg' },
                { id: 'piece39', order: 3, img: 'images/image39.jpg' },
                { id: 'piece40', order: 4, img: 'images/image40.jpg' },
                { id: 'piece41', order: 5, img: 'images/image41.jpg' },
                { id: 'piece42', order: 6, img: 'images/image42.jpg' },
                { id: 'piece43', order: 7, img: 'images/image43.jpg' },
                { id: 'piece44', order: 8, img: 'images/image44.jpg' },
                { id: 'piece45', order: 9, img: 'images/image45.jpg' },
            ],
            finalImage: 'images/final-image5.jpg'
        }
    ];

    let currentLevel = 0;
    const levelIndicator = document.getElementById('level-indicator');
    const puzzleBoard = document.getElementById('puzzle-board');
    const piecesContainer = document.getElementById('pieces-container');
    const finalProduct = document.getElementById('final-product');
    const finalProductImage = finalProduct.querySelector('img');
    const congratulationsPopup = document.getElementById('congratulations-popup');
    const closePopupButton = document.getElementById('close-popup');
    const backgroundMusic = document.getElementById('background-music');

    closePopupButton.addEventListener('click', () => {
        congratulationsPopup.classList.add('hide');
        location.reload();
    });

    function initLevel(level) {
        levelIndicator.textContent = `Nivel: ${level + 1}`;
        puzzleBoard.innerHTML = '';
        piecesContainer.innerHTML = '';

        const gridTemplate = 'repeat(3, 1fr) / repeat(3, 1fr)';
        puzzleBoard.style.gridTemplate = gridTemplate;

        levels[level].pieces.forEach((piece, index) => {
            const slot = document.createElement('div');
            slot.classList.add('slot');
            slot.dataset.order = index + 1;
            puzzleBoard.appendChild(slot);
        });

        shuffleArray(levels[level].pieces).forEach(piece => {
            const pieceElement = document.createElement('div');
            pieceElement.classList.add('piece');
            pieceElement.id = piece.id;
            pieceElement.draggable = true;
            pieceElement.innerHTML = `<img src="${piece.img}" alt="Puzzle Piece">`;
            piecesContainer.appendChild(pieceElement);
        });

        addDragAndDropEventListeners();
    }

    function shuffleArray(array) {
        for (let i = array.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [array[i], array[j]] = [array[j], array[i]];
        }
        return array;
    }

    function addDragAndDropEventListeners() {
        const pieces = document.querySelectorAll('.piece');
        const slots = document.querySelectorAll('.slot');

        pieces.forEach(piece => {
            piece.addEventListener('dragstart', dragStart);
            piece.addEventListener('dragend', dragEnd);
        });

        slots.forEach(slot => {
            slot.addEventListener('dragover', dragOver);
            slot.addEventListener('dragenter', dragEnter);
            slot.addEventListener('dragleave', dragLeave);
            slot.addEventListener('drop', drop);
        });
    }

    function dragStart(event) {
        event.dataTransfer.setData('text/plain', event.target.id);
        setTimeout(() => {
            event.target.classList.add('hide');
        }, 0);
    }

    function dragEnd(event) {
        event.target.classList.remove('hide');
    }

    function dragOver(event) {
        event.preventDefault();
    }

    function dragEnter(event) {
        event.preventDefault();
        event.target.classList.add('drag-over');
    }

    function dragLeave(event) {
        event.target.classList.remove('drag-over');
    }

    function drop(event) {
        event.target.classList.remove('drag-over');

        const pieceId = event.dataTransfer.getData('text/plain');
        const draggedPiece = document.getElementById(pieceId);
        const pieceOrder = levels[currentLevel].pieces.find(piece => piece.id === pieceId).order;
        const slotOrder = event.target.dataset.order;

        if (pieceOrder === parseInt(slotOrder)) {
            event.target.appendChild(draggedPiece);
        }

        checkLevelCompletion();
    }

    function checkLevelCompletion() {
        const slots = document.querySelectorAll('.slot');
        const isComplete = Array.from(slots).every(slot => slot.children.length > 0);

        if (isComplete) {
            finalProductImage.src = levels[currentLevel].finalImage;
            finalProduct.style.display = 'block';

            setTimeout(() => {
                finalProduct.style.display = 'none';
                currentLevel++;

                if (currentLevel < levels.length) {
                    initLevel(currentLevel);
                } else {
                    showCongratulationsPopup();
                }
            }, 5000);
        }
    }

    function showCongratulationsPopup() {
        congratulationsPopup.classList.remove('hide');
    }

    initLevel(currentLevel);
    backgroundMusic.play();
});
